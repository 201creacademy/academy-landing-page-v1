# Responsive-Food-Landing-Page
Html Css Javascript flex scroll 

https://quocbinh-npm9081.github.io/Responsive-Food-Landing-Page/

![screencapture-file-D-projectsv2-food-landing-page-index-html-2020-11-19-15_09_23](https://user-images.githubusercontent.com/68917523/147425716-80816371-ddd3-4ad9-b60b-fd6d5fc6f211.png)
